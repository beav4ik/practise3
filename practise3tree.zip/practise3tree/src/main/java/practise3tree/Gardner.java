package practise3tree;

public class Gardner {
    public void change(Plant plant){
        String newName = plant.getName();
        String newName2 = newName.replaceAll("а","");
        String newName3 = newName2.replaceAll("е","");
        String newName4 = newName3.replaceAll("ё","");
        String newName5 = newName4.replaceAll("и","");
        String newName6 = newName5.replaceAll("о","");
        String newName7 = newName6.replaceAll("у","");
        String newName8 = newName7.replaceAll("ы","");
        String newName9 = newName8.replaceAll("э","");
        String newName10 = newName9.replaceAll("ю","");
        String newName11 = newName10.replaceAll("я","");
        String newName12 = newName11.replaceAll("А","");
        String newName13 = newName12.replaceAll("Е","");
        String newName14 = newName13.replaceAll("Ё","");
        String newName15 = newName14.replaceAll("и","");
        String newName16 = newName15.replaceAll("О","");
        String newName17 = newName16.replaceAll("У","");
        String newName18 = newName17.replaceAll("Ы","");
        String newName19 = newName18.replaceAll("Э","");
        String newName20 = newName19.replaceAll("Ю","");
        String newName21 = newName20.replaceAll("Я","");
        String newName22 = newName21 + "VGTBL";
        plant.setName(newName22);
    }
}

