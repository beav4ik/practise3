package practise3tree;

public class Plant {
        private String name;
        private int age;
        private String area;
        private String plant;

        public Plant(String name, int age, String area) {
            this.name = name;
            this.age = age;
            this.area = area;
        }

        public String getName() {
            return name;
        }

        public void setName(String plant) {
            this.plant = name;
        }

        public int getAge() {
            return age;
        }

        public String getArea() {
            return area;
        }
        @Override
        public String toString(){
            return plant;
        }


    }
