
package practise3tree;

public class NotFruity extends Tree{
    private String barkColor;

    public NotFruity(String barkColor, String type, double height, String name, int age, String area) {
        super(type, height, name, age, area);
        this.barkColor = barkColor;
    }

    public String getBarkColor() {
        return barkColor;
    }
    @Override
    public String toString() {
        return "Ваше дерево --->" + " Название: " + getName() + ", Возраст: " + getAge() + ", Зона произрастания: " + getArea() + ", Семейство: " + getType() + ", Высота: " + getHeight() + ", Цвет коры: " + getBarkColor() + " <---";
    }

}
