package practise3tree;

import java.util.Scanner;

public class practise3tree {
        public static void main(String[] args) {
            Scanner scan = new Scanner(System.in);
            System.out.println("Практическая работа №2-3, Вариант 4, РИБО-01-21, Бобровский С.И.");
            System.out.println("Введите название растения (на русском языке): ");
            String name = scan.next();
            System.out.println("Введите возраст растения (полных лет): ");
            int age = scan.nextInt();
            System.out.println("Введите место обитания растения: ");
            String area = scan.next();
            Plant plant = new Plant(name,age,area);
            Gardner gardner1 = new Gardner();
            gardner1.change(plant);
            System.out.println("Выберите цифру: 1 - Дерево, 2 - Небольшое растение");
            int a = scan.nextInt();
            if (a == 1) {
                System.out.println("Введите семейство растения: ");
                String type = scan.next();
                System.out.println("Введите высоту (в метрах): ");
                double hg = scan.nextDouble();
                System.out.println("Выберите цифру: 1 - Фруктовое дерево, 2 - Не фруктовое дерево");
                int i = scan.nextInt();
                if (i == 1) {
                    System.out.println("Введите название плодов: ");
                    String frNm = scan.next();
                    Fruit plant1 = new Fruit(frNm, type, hg, name, age, area);
                    System.out.println(plant1.toString());
                }
                else {
                    System.out.println("Введите цвет коры: ");
                    String brcСlr = scan.next();
                    NotFruity plant2 = new NotFruity(brcСlr, type, hg, name, age, area);
                    System.out.println(plant2.toString());
                }
            }else {
                System.out.println("Введите длину корня (в метрах): ");
                int rtLgth = scan.nextInt();
                System.out.println("Введите климатическую зону расположения растения: ");
                String clZn = scan.next();
                System.out.println("Выберите цифру: 1 - Куст, 2 - цветок, 3 - плодовое растение");
                int b = scan.nextInt();
                switch (b) {
                    case 1:
                        System.out.println("Введите длину листьев: ");
                        double leafSz = scan.nextDouble();
                        Bush plant3 = new Bush(leafSz, rtLgth, clZn, name, age, area);
                        System.out.println(plant3.toString());
                        break;
                    case 2:
                        System.out.println("Введите цвет цветка: ");
                        String clr = scan.next();
                        Flower plant5 = new Flower(clr, rtLgth, clZn, name, age, area);
                        System.out.println(plant5.toString());
                        break;
                }
            }
        }

    }

