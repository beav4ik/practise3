
package practise3tree;


public class SmallPlant extends Plant{
    private double rootLength;
    private String climateZone;

    public SmallPlant(double rootLength, String climateZone, String name, int age, String area) {
        super(name, age, area);
        this.rootLength = rootLength;
        this.climateZone = climateZone;
    }

    public double getRootLength() {
        return rootLength;
    }


    public String getClimateZone() {
        return climateZone;
    }

    public void setClimateZone(String climateZone) {
        this.climateZone = climateZone;
    }



}
