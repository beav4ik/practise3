package practise3tree;

public class Bush extends SmallPlant{
    private double leafSize;

    public Bush(double leafSize, double rootLength, String climateZone, String name, int age, String area) {
        super(rootLength, climateZone, name, age, area);
        this.leafSize = leafSize;
    }

    public double getLeafSize() {

        return leafSize;
    }

    @Override
    public String toString() {
        return "Ваше дерево --->" + " Название: " + getName() + ", Возраст: " + getAge() + ", Зона произрастания: " + getArea() + ", Длина корня: " + getRootLength() + ", Климатическая зона: " + getClimateZone() + ", Длина листьев: " + getLeafSize() + " <---";
    }

}
