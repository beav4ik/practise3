
package practise3tree;


public class Fruit extends Tree{
    private String fruitName;

    public Fruit(String fruitName, String type, double height, String name, int age, String area) {
        super(type, height, name, age, area);
        this.fruitName = fruitName;
    }

    public String getFruitName() {

        return fruitName;
    }

    @Override
    public String toString() {
        return "Ваше дерево --->" + " Название: " + getName() + ", Возраст: " + getAge() + ", Зона произрастания: " + getArea() + ", Семейство: " + getType() + ", Высота: " + getHeight() + ", Название плодов: " + getFruitName() + " <---";
    }

}
