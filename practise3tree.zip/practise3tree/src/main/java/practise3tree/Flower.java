
package practise3tree;


public class Flower extends SmallPlant{
    private String color;

    public Flower(String color, double rootLength, String climateZone, String name, int age, String area) {
        super(rootLength, climateZone, name, age, area);
        this.color = color;
    }

    public String getColor() {

        return color;
    }

    @Override
    public String toString() {
        return "Ваш цветок --->" + " Название: " + getName() + ", Возраст: " + getAge() + ", Зона произрастания: " + getArea() + ", Длина корня: " + getRootLength() + ", Климатическая зона: " + getClimateZone() + ", Цвет: " + getColor() + " <---";
    }

}
