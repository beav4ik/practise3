package practise3tree;public class Tree {
}
